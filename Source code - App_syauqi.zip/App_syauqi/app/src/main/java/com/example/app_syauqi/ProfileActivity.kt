package com.example.app_syauqi

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val username = intent.getStringExtra("USERNAME") ?: "User"

        val textView = findViewById<TextView>(R.id.text_profile)
        textView.text = "Halo, $username"
    }
}